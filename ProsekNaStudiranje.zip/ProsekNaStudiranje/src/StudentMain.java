import java.util.Scanner;
public class StudentMain
{
    public static void main(String[] args)
    {
        Student s=getStudentDetails();
        s.calculateAvg();
        System.out.println("Indeks:" +s.getId());
        System.out.println("Ime:" +s.getName());
        System.out.println("Prosek:"+String.format("%.2f",s.getAverage()));
    }
    public static Student getStudentDetails()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Vnesi go brojot na indeks:");
        int id=Integer.parseInt(sc.nextLine());
        System.out.println("Vnesi go imeto:");
        String name=sc.nextLine();
        System.out.println("Vnesi go brojot na predmeti:");
        int n=sc.nextInt();
        if(n<=0)
        {
            while(n<=0)
            {
                System.out.println("Greska!");
                System.out.println("Vnesi go brojot na predmeti:");
                n=sc.nextInt();
            }
        }
        int arr[]=new int[n];
        for(int a=0;a<n;a++)
        {
            System.out.println("Vnesi ja ocenata po predmetot "+(a+1)+":");
            int b=sc.nextInt();
            while(b<6||b>10)
            {
               
                    System.out.println("Gresna ocena!");
                    System.out.println("Vnesi ja ocenata po predmetot " + (a + 1) + ":");
                    b = sc.nextInt();
                }
            arr[a]=b;
        }
        Student obj=new Student(id,name,arr);
        obj.setId(id);
        obj.setName(name);
        return obj;
    }
}

